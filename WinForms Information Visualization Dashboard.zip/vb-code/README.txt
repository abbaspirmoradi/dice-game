CLAIM WORKFLOW MONITOR — WinForms dashboard
============================================

Files (add all four to your existing WinForms project):
  1. WorkflowDashboardModels.vb      - DTOs (snapshots, metrics, alerts)
  2. WorkflowMetricsBO.vb            - business object: fetch + compute all metrics
  3. WorkflowDashboardController.vb  - thin controller (Form -> Controller -> BO -> DLC)
  4. WorkflowDashboardForm.vb        - the dashboard form (all UI built in code, no Designer file)

Prerequisites already in your project (you provided these):
  - ClaimWorkflowHistory        (entity with SetFromDataRow)
  - ClaimWorkflowHistoryDLC     (Oracle data access, GetWorkflowHistory)
  - DatabaseCon.GetConnection()

Setup steps:
  1. Add the four .vb files to the project.
  2. Add references to:  System.Windows.Forms.DataVisualization
     (Project > Add Reference > Assemblies > System.Windows.Forms.DataVisualization)
     and System.IO.Compression (used by the .xlsx Excel export; .NET 4.5+)
  3. Show the form, e.g.:
        Dim f As New WorkflowDashboardForm()
        f.Show()

Notes:
  - The Status filter is applied client-side on workflow snapshots
    (COMPLETED / FAILED / RUNNING are derived states, not raw DB values),
    so the existing DLC signature is unchanged.
  - Alert thresholds are constants at the top of WorkflowMetricsBO
    (failure rate 10%, bottleneck factor 2x median, long-running 120 s,
    slow step 30 s). Tune them there.
  - Auto-refresh is a 30 s Timer, toggled by the checkbox in the filter bar.
  - Layout is fully responsive: TableLayoutPanel percentages + a SplitContainer
    between the live grid and the drill-down grid.
  - A workflow is COMPLETED when its last step is WORKFLOW_COMPLETED/COMPLETED,
    FAILED when any step has STATUS = FAILED, otherwise RUNNING
    (duration measured against client clock; consider DB time if servers drift).
