' =====================================================================
'  WorkflowDashboardController.vb
'  Thin controller between the Form and the business object.
'  Form -> Controller -> WorkflowMetricsBO -> ClaimWorkflowHistoryDLC
' =====================================================================
Option Explicit On

Imports System.Collections.Generic

Public Class WorkflowDashboardController

    Private ReadOnly mBO As New WorkflowMetricsBO

    ''' <summary>Recompute all metrics from an in-memory record subset (client-side id filtering).</summary>
    Public Function Recompute(ByVal records As List(Of ClaimWorkflowHistory),
                              ByVal pFromTime As Date,
                              ByVal pToTime As Date) As DashboardMetrics
        Return mBO.Compute(records, pFromTime, pToTime)
    End Function

    ''' <summary>Fetch and compute all dashboard metrics for the given filters.</summary>
    Public Function GetDashboard(ByVal pFromTime As Date,
                                 ByVal pToTime As Date,
                                 Optional ByVal pWorkerID As String = "",
                                 Optional ByVal pStatusFilter As String = "") As DashboardMetrics
        If pToTime < pFromTime Then
            Throw New ArgumentException("Invalid time range: 'To' must be after 'From'.")
        End If
        If String.Equals(pWorkerID, "All", StringComparison.OrdinalIgnoreCase) Then pWorkerID = ""
        Return mBO.GetDashboard(pFromTime, pToTime, pWorkerID, pStatusFilter)
    End Function

End Class
