' =====================================================================
'  WorkflowDashboardController.vb
'  Thin controller between the Form and the business object.
'  Form -> Controller -> WorkflowMetricsBO -> ClaimWorkflowHistoryDLC
' =====================================================================
Option Explicit On

Public Class WorkflowDashboardController

    Private ReadOnly mBO As New WorkflowMetricsBO

    ''' <summary>Fetch and compute all dashboard metrics for the given filters.</summary>
    Public Function GetDashboard(ByVal pFromTime As Date,
                                 ByVal pToTime As Date,
                                 Optional ByVal pWorkerID As String = "",
                                 Optional ByVal pStatusFilter As String = "") As DashboardMetrics
        If pToTime < pFromTime Then
            Throw New ArgumentException("Invalid time range: 'To' must be after 'From'.")
        End If
        If String.Equals(pWorkerID, "All", StringComparison.OrdinalIgnoreCase) Then pWorkerID = ""
        Return mBO.GetDashboard(pFromTime, pToTime, pWorkerID, pStatusFilter)
    End Function

End Class
