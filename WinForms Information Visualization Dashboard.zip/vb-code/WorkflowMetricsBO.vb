' =====================================================================
'  WorkflowMetricsBO.vb
'  Business object: fetches raw history via ClaimWorkflowHistoryDLC,
'  maps rows to ClaimWorkflowHistory objects and computes all
'  dashboard metrics (KPIs, funnel, step durations, trend, alerts).
' =====================================================================
Option Explicit On

Imports System.Data
Imports System.Linq
Imports System.Collections.Generic

Public Class WorkflowMetricsBO

    Private ReadOnly mDLC As New ClaimWorkflowHistoryDLC

    ' --- Alert thresholds (tune to your environment) ---
    Public Const FAILURE_RATE_PCT_THRESHOLD As Double = 10.0
    Public Const BOTTLENECK_FACTOR As Double = 2.0        ' step avg > factor x median of step avgs
    Public Const LONG_RUNNING_SEC As Double = 120.0       ' running workflow older than this
    Public Const SLOW_STEP_SEC As Double = 30.0           ' warn when a step avg exceeds this

    ' Canonical lifecycle order for the funnel
    Private Shared ReadOnly StepOrder As String() = {
        "New", "SearchExistingClaim", "SearchExistingWorksheet",
        "SearchInforce", "SearchEdi", "CreateWorksheet",
        "AttachDocuments", "SystemGeneratedEmail", "WORKFLOW_COMPLETED"}

    ''' <summary>Main entry point: fetch + compute everything for one refresh.</summary>
    Public Function GetDashboard(ByVal pFromTime As Date,
                                 ByVal pToTime As Date,
                                 Optional ByVal pWorkerID As String = "",
                                 Optional ByVal pStatusFilter As String = "") As DashboardMetrics

        Dim oTable As DataTable = mDLC.GetWorkflowHistory(pFromTime, pToTime, pWorkerID)

        Dim records As New List(Of ClaimWorkflowHistory)
        For Each row As DataRow In oTable.Rows
            Dim rec As New ClaimWorkflowHistory
            rec.SetFromDataRow(row)
            records.Add(rec)
        Next

        Return Compute(records, pFromTime, pToTime, pStatusFilter)
    End Function

    ''' <summary>Pure computation — unit-testable without a database.</summary>
    Public Function Compute(ByVal records As List(Of ClaimWorkflowHistory),
                            ByVal pFromTime As Date,
                            ByVal pToTime As Date,
                            Optional ByVal pStatusFilter As String = "") As DashboardMetrics

        Dim m As New DashboardMetrics With {.FromTime = pFromTime, .ToTime = pToTime}
        If records Is Nothing Then records = New List(Of ClaimWorkflowHistory)

        ' ---------- 1. Group into per-workflow snapshots ----------
        ' Primary key = SUBMISSION_ID + RECORD_CASE_ID (one workflow per combination)
        Dim groups = records.
            Where(Function(r) Not String.IsNullOrEmpty(r.SUBMISSIONID)).
            GroupBy(Function(r) r.SUBMISSIONID & "|" & r.RECORDCASEID)

        For Each g In groups
            Dim steps As List(Of ClaimWorkflowHistory) =
                g.OrderBy(Function(r) r.STARTTS).ToList()
            Dim first As ClaimWorkflowHistory = steps.First()
            Dim lastStep As ClaimWorkflowHistory = steps.Last()

            Dim snap As New WorkflowSnapshot With {
                .SubmissionId = first.SUBMISSIONID,
                .RecordCaseId = first.RECORDCASEID,
                .CurrentStep = lastStep.STEPNAME,
                .ResultCode = lastStep.RESULTCODE,
                .WorkerId = lastStep.WORKERID,
                .StartTs = first.STARTTS,
                .Steps = steps
            }

            ' Overall status
            If steps.Any(Function(s) String.Equals(s.STATUS, "FAILED", StringComparison.OrdinalIgnoreCase)) Then
                snap.Status = "FAILED"
                Dim failedStep = steps.Last(Function(s) String.Equals(s.STATUS, "FAILED", StringComparison.OrdinalIgnoreCase))
                snap.CurrentStep = failedStep.STEPNAME
                snap.ErrorMessage = If(String.IsNullOrEmpty(failedStep.ERRORMESSAGE), failedStep.RESULTDETAILS, failedStep.ERRORMESSAGE)
            ElseIf String.Equals(lastStep.STEPNAME, "WORKFLOW_COMPLETED", StringComparison.OrdinalIgnoreCase) AndAlso
                   String.Equals(lastStep.STATUS, "COMPLETED", StringComparison.OrdinalIgnoreCase) Then
                snap.Status = "COMPLETED"
            Else
                snap.Status = "RUNNING"
            End If

            ' End timestamp + duration
            If snap.Status = "RUNNING" Then
                snap.EndTs = Date.MinValue
                snap.DurationSec = (Date.Now - snap.StartTs).TotalSeconds
            Else
                snap.EndTs = steps.Max(Function(s) s.ENDTS)
                If snap.EndTs > Date.MinValue Then
                    snap.DurationSec = (snap.EndTs - snap.StartTs).TotalSeconds
                End If
            End If
            If snap.DurationSec < 0 Then snap.DurationSec = 0

            ' Worksheet id: CREATED_WORKSHEET_ID from CreateWorksheet takes priority
            Dim ws = steps.Select(Function(s) s.CREATEDWORKSHEETID).
                           FirstOrDefault(Function(v) Not String.IsNullOrEmpty(v) AndAlso v <> "0")
            If Not String.IsNullOrEmpty(ws) Then
                snap.WorksheetCreated = True   ' service created a new worksheet
            Else
                ws = steps.SelectMany(Function(s) SplitIds(s.WORKSHEETIDS)).FirstOrDefault()
            End If
            snap.WorksheetId = If(ws, "")

            ' Latest details / error for the live grid
            If snap.Status = "FAILED" Then
                snap.LastDetails = snap.ErrorMessage
            Else
                snap.LastDetails = If(String.IsNullOrEmpty(lastStep.ERRORMESSAGE), lastStep.RESULTDETAILS, lastStep.ERRORMESSAGE)
            End If

            m.Snapshots.Add(snap)
        Next

        ' Optional status filter (client side, keeps DLC unchanged)
        If Not String.IsNullOrWhiteSpace(pStatusFilter) AndAlso pStatusFilter <> "All" Then
            m.Snapshots = m.Snapshots.
                Where(Function(s) String.Equals(s.Status, pStatusFilter, StringComparison.OrdinalIgnoreCase)).ToList()
        End If

        ' Newest activity first
        m.Snapshots = m.Snapshots.OrderByDescending(Function(s) s.StartTs).ToList()
        m.Workers = m.Snapshots.Select(Function(s) s.WorkerId).
                    Where(Function(w) Not String.IsNullOrEmpty(w)).Distinct().OrderBy(Function(w) w).ToList()

        ' ---------- 2. Executive KPIs ----------
        m.TotalWorkflows = m.Snapshots.Count
        m.SuccessCount = m.Snapshots.Count(Function(s) s.Status = "COMPLETED")
        m.FailureCount = m.Snapshots.Count(Function(s) s.Status = "FAILED")
        m.InProgressCount = m.Snapshots.Count(Function(s) s.Status = "RUNNING")
        If m.TotalWorkflows > 0 Then
            m.SuccessPct = m.SuccessCount * 100.0 / m.TotalWorkflows
            m.FailurePct = m.FailureCount * 100.0 / m.TotalWorkflows
        End If

        Dim finished = m.Snapshots.Where(Function(s) s.Status <> "RUNNING" AndAlso s.DurationSec > 0).
                                   Select(Function(s) s.DurationSec).OrderBy(Function(d) d).ToList()
        If finished.Count > 0 Then
            m.AvgDurationSec = finished.Average()
            m.P95DurationSec = finished(Math.Min(finished.Count - 1, CInt(Math.Ceiling(finished.Count * 0.95)) - 1))
        End If
        Dim running = m.Snapshots.Where(Function(s) s.Status = "RUNNING").ToList()
        If running.Count > 0 Then m.OldestRunningSec = running.Max(Function(s) s.DurationSec)

        ' ---------- 3. Funnel ----------
        For Each stepName In StepOrder
            Dim n As Integer = m.Snapshots.Count(
                Function(s) s.Steps.Any(Function(r) String.Equals(r.STEPNAME, stepName, StringComparison.OrdinalIgnoreCase)))
            m.Funnel.Add(New StepCount With {
                .StepName = stepName, .Count = n,
                .Pct = If(m.TotalWorkflows > 0, n * 100.0 / m.TotalWorkflows, 0)})
        Next

        ' ---------- 4. Step duration metrics + bottlenecks ----------
        Dim stepGroups = records.
            Where(Function(r) r.ENDTS > Date.MinValue AndAlso r.STARTTS > Date.MinValue AndAlso r.ENDTS >= r.STARTTS).
            GroupBy(Function(r) r.STEPNAME)
        For Each sg In stepGroups
            Dim durs = sg.Select(Function(r) (r.ENDTS - r.STARTTS).TotalSeconds).ToList()
            m.StepDurations.Add(New StepDuration With {
                .StepName = sg.Key, .AvgSec = durs.Average(),
                .MaxSec = durs.Max(), .SampleCount = durs.Count})
        Next
        ' order by canonical lifecycle position
        m.StepDurations = m.StepDurations.
            OrderBy(Function(s) Array.IndexOf(StepOrder, s.StepName)).ToList()

        If m.StepDurations.Count > 1 Then
            Dim avgs = m.StepDurations.Select(Function(s) s.AvgSec).OrderBy(Function(d) d).ToList()
            Dim median As Double = avgs(avgs.Count \ 2)
            If median > 0 Then
                For Each sd In m.StepDurations
                    sd.IsBottleneck = sd.AvgSec > median * BOTTLENECK_FACTOR AndAlso sd.AvgSec >= SLOW_STEP_SEC
                Next
            End If
        End If

        ' ---------- 5. Trend (per-minute buckets) ----------
        Dim bucketStart As Date = New Date(pFromTime.Year, pFromTime.Month, pFromTime.Day, pFromTime.Hour, pFromTime.Minute, 0)
        Dim totalMinutes As Integer = CInt(Math.Ceiling((pToTime - bucketStart).TotalMinutes))
        Dim stepMin As Integer = Math.Max(1, CInt(Math.Ceiling(totalMinutes / 240.0))) ' cap ~240 buckets
        Dim t As Date = bucketStart
        While t <= pToTime
            Dim bFrom As Date = t
            Dim bTo As Date = t.AddMinutes(stepMin)
            m.Trend.Add(New TrendPoint With {
                .BucketStart = bFrom,
                .Completed = m.Snapshots.Count(Function(s) s.Status = "COMPLETED" AndAlso s.EndTs >= bFrom AndAlso s.EndTs < bTo),
                .Failed = m.Snapshots.Count(Function(s) s.Status = "FAILED" AndAlso s.EndTs >= bFrom AndAlso s.EndTs < bTo)})
            t = bTo
        End While

        ' ---------- 6. Alerts ----------
        If m.TotalWorkflows > 0 AndAlso m.FailurePct > FAILURE_RATE_PCT_THRESHOLD Then
            m.Alerts.Add(New AlertItem With {
                .Severity = "CRITICAL",
                .Title = String.Format("Failure rate {0:F1}%", m.FailurePct),
                .Detail = String.Format("{0} of {1} workflows failed in selected range (threshold {2:F0}%)",
                                        m.FailureCount, m.TotalWorkflows, FAILURE_RATE_PCT_THRESHOLD)})
        End If
        For Each sd In m.StepDurations.Where(Function(s) s.IsBottleneck)
            m.Alerts.Add(New AlertItem With {
                .Severity = "CRITICAL",
                .Title = "Bottleneck: " & sd.StepName,
                .Detail = String.Format("avg {0:F1} s over {1} executions (max {2:F1} s)",
                                        sd.AvgSec, sd.SampleCount, sd.MaxSec)})
        Next
        For Each sd In m.StepDurations.Where(Function(s) Not s.IsBottleneck AndAlso s.AvgSec >= SLOW_STEP_SEC)
            m.Alerts.Add(New AlertItem With {
                .Severity = "WARNING",
                .Title = "Slow step: " & sd.StepName,
                .Detail = String.Format("avg {0:F1} s over {1} executions", sd.AvgSec, sd.SampleCount)})
        Next
        For Each s In m.Snapshots.Where(Function(x) x.Status = "RUNNING" AndAlso x.DurationSec > LONG_RUNNING_SEC)
            m.Alerts.Add(New AlertItem With {
                .Severity = "WARNING",
                .Title = "Long-running workflow",
                .Detail = String.Format("{0} running {1:F0} s at {2}", s.SubmissionId, s.DurationSec, s.CurrentStep)})
        Next
        ' CRITICAL first
        m.Alerts = m.Alerts.OrderBy(Function(a) If(a.Severity = "CRITICAL", 0, 1)).ToList()

        Return m
    End Function

    Private Shared Function SplitIds(ByVal csv As String) As IEnumerable(Of String)
        If String.IsNullOrWhiteSpace(csv) Then Return Enumerable.Empty(Of String)()
        Return csv.Split(","c).Select(Function(x) x.Trim()).Where(Function(x) x.Length > 0)
    End Function

End Class
