' =====================================================================
'  WorkflowDashboardForm.vb
'  Claim Workflow Monitor — main dashboard form.
'  All controls are created in code (no .Designer.vb needed).
'
'  REQUIRED PROJECT REFERENCES:
'    - System.Windows.Forms.DataVisualization   (MSChart, .NET Framework)
'
'  Layout (top -> bottom):
'    Filters | Alerts | KPIs | Funnel + Step durations | Trend | Live grid | Drill-down
' =====================================================================
Option Explicit On

Imports System.Collections.Generic
Imports System.Drawing
Imports System.Linq
Imports System.Windows.Forms
Imports System.Windows.Forms.DataVisualization.Charting

Public Class WorkflowDashboardForm
    Inherits Form

    ' ---- palette (status colors only, per design spec) ----
    Private Shared ReadOnly ClrGreen As Color = Color.FromArgb(30, 123, 52)
    Private Shared ReadOnly ClrGreenBg As Color = Color.FromArgb(231, 243, 234)
    Private Shared ReadOnly ClrRed As Color = Color.FromArgb(179, 38, 30)
    Private Shared ReadOnly ClrRedBg As Color = Color.FromArgb(251, 234, 233)
    Private Shared ReadOnly ClrRedRow As Color = Color.FromArgb(253, 244, 243)
    Private Shared ReadOnly ClrAmber As Color = Color.FromArgb(178, 106, 0)
    Private Shared ReadOnly ClrAmberBg As Color = Color.FromArgb(253, 243, 227)
    Private Shared ReadOnly ClrAmberRow As Color = Color.FromArgb(254, 250, 241)
    Private Shared ReadOnly ClrBar As Color = Color.FromArgb(74, 121, 168)
    Private Shared ReadOnly ClrBarSlow As Color = Color.FromArgb(208, 135, 0)
    Private Shared ReadOnly ClrHeaderDark As Color = Color.FromArgb(36, 48, 61)
    Private Shared ReadOnly ClrPanelBorder As Color = Color.FromArgb(200, 203, 208)
    Private Shared ReadOnly ClrGridHead As Color = Color.FromArgb(244, 245, 246)
    Private Shared ReadOnly ClrTextMuted As Color = Color.FromArgb(85, 96, 107)

    ' ---- services ----
    Private ReadOnly mController As New WorkflowDashboardController
    Private mMetrics As DashboardMetrics
    Private mCurrentSnap As WorkflowSnapshot

    ' ---- filter controls ----
    Private cboRange As ComboBox
    Private dtpFrom As DateTimePicker
    Private dtpTo As DateTimePicker
    Private cboWorker As ComboBox
    Private cboStatus As ComboBox
    Private btnRefresh As Button
    Private chkAuto As CheckBox
    Private tmrAuto As Timer
    Private lblLastRefresh As Label

    ' ---- panels / content controls ----
    Private pnlAlertsList As FlowLayoutPanel
    Private lblAlertCount As Label
    Private lblKpiTotal, lblKpiSuccess, lblKpiFailure, lblKpiAvg, lblKpiRunning As Label
    Private lblKpiTotalSub, lblKpiSuccessSub, lblKpiFailureSub, lblKpiAvgSub, lblKpiRunningSub As Label
    Private chartFunnel As Chart
    Private chartSteps As Chart
    Private chartTrend As Chart
    Private dgvLive As DataGridView
    Private dgvDetail As DataGridView
    Private lblDetailTitle As Label
    Private lblLiveTitle As Label
    Private txtSubFilter As TextBox
    Private txtCaseFilter As TextBox

    Public Sub New()
        Me.Text = "Claim Workflow Monitor"
        Me.Font = New Font("Segoe UI", 9.0F)
        Me.BackColor = Color.FromArgb(231, 233, 236)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.WindowState = FormWindowState.Maximized
        Me.MinimumSize = New Size(1200, 800)
        BuildUi()
        AddHandler Me.Shown, Sub() RefreshData()
    End Sub

    ' =================================================================
    '  UI CONSTRUCTION
    ' =================================================================
    Private Sub BuildUi()

        Dim root As New TableLayoutPanel With {
            .Dock = DockStyle.Fill, .ColumnCount = 1, .RowCount = 6,
            .Padding = New Padding(12, 8, 12, 12), .BackColor = Me.BackColor}
        root.RowStyles.Add(New RowStyle(SizeType.AutoSize))            ' filters
        root.RowStyles.Add(New RowStyle(SizeType.Absolute, 108))       ' alerts
        root.RowStyles.Add(New RowStyle(SizeType.Absolute, 96))        ' KPIs
        root.RowStyles.Add(New RowStyle(SizeType.Percent, 34))         ' funnel + steps
        root.RowStyles.Add(New RowStyle(SizeType.Percent, 22))         ' trend
        root.RowStyles.Add(New RowStyle(SizeType.Percent, 44))         ' grids
        Me.Controls.Add(root)

        root.Controls.Add(BuildFilterBar(), 0, 0)
        root.Controls.Add(BuildAlertsPanel(), 0, 1)
        root.Controls.Add(BuildKpiRow(), 0, 2)
        root.Controls.Add(BuildTopCharts(), 0, 3)
        root.Controls.Add(BuildTrendChart(), 0, 4)
        root.Controls.Add(BuildGrids(), 0, 5)

        tmrAuto = New Timer With {.Interval = 30000}
        AddHandler tmrAuto.Tick, Sub() RefreshData()
    End Sub

    Private Function BuildFilterBar() As Control
        Dim pnl As New FlowLayoutPanel With {
            .Dock = DockStyle.Fill, .AutoSize = True, .WrapContents = True,
            .BackColor = Color.FromArgb(244, 245, 246), .Padding = New Padding(8, 6, 8, 6),
            .Margin = New Padding(0, 0, 0, 8)}

        pnl.Controls.Add(MakeFilterLabel("Range"))
        cboRange = New ComboBox With {.DropDownStyle = ComboBoxStyle.DropDownList, .Width = 140}
        cboRange.Items.AddRange(New Object() {"Last 15 minutes", "Last 30 minutes", "Last 1 hour", "Last 4 hours", "Today", "Custom"})
        cboRange.SelectedIndex = 0
        AddHandler cboRange.SelectedIndexChanged, AddressOf OnRangeChanged
        pnl.Controls.Add(cboRange)

        pnl.Controls.Add(MakeFilterLabel("From"))
        dtpFrom = New DateTimePicker With {.Format = DateTimePickerFormat.Custom, .CustomFormat = "MM/dd/yyyy HH:mm", .Width = 150}
        pnl.Controls.Add(dtpFrom)

        pnl.Controls.Add(MakeFilterLabel("To"))
        dtpTo = New DateTimePicker With {.Format = DateTimePickerFormat.Custom, .CustomFormat = "MM/dd/yyyy HH:mm", .Width = 150}
        pnl.Controls.Add(dtpTo)

        pnl.Controls.Add(MakeFilterLabel("Worker"))
        cboWorker = New ComboBox With {.DropDownStyle = ComboBoxStyle.DropDownList, .Width = 110}
        cboWorker.Items.Add("All") : cboWorker.SelectedIndex = 0
        pnl.Controls.Add(cboWorker)

        pnl.Controls.Add(MakeFilterLabel("Status"))
        cboStatus = New ComboBox With {.DropDownStyle = ComboBoxStyle.DropDownList, .Width = 110}
        cboStatus.Items.AddRange(New Object() {"All", "COMPLETED", "FAILED", "RUNNING"})
        cboStatus.SelectedIndex = 0
        pnl.Controls.Add(cboStatus)

        btnRefresh = New Button With {
            .Text = "Refresh", .BackColor = Color.FromArgb(47, 92, 143), .ForeColor = Color.White,
            .FlatStyle = FlatStyle.Flat, .Width = 100, .Height = 26, .Margin = New Padding(16, 2, 4, 2)}
        btnRefresh.FlatAppearance.BorderSize = 0
        AddHandler btnRefresh.Click, Sub() RefreshData()
        pnl.Controls.Add(btnRefresh)

        chkAuto = New CheckBox With {.Text = "Auto-refresh 30 s", .AutoSize = True, .Margin = New Padding(10, 6, 4, 2)}
        AddHandler chkAuto.CheckedChanged, Sub() tmrAuto.Enabled = chkAuto.Checked
        pnl.Controls.Add(chkAuto)

        lblLastRefresh = New Label With {.Text = "", .AutoSize = True, .ForeColor = ClrTextMuted, .Margin = New Padding(14, 8, 4, 2)}
        pnl.Controls.Add(lblLastRefresh)

        ApplyRangePreset()
        Return Bordered(pnl)
    End Function

    Private Function BuildAlertsPanel() As Control
        Dim host As New Panel With {.Dock = DockStyle.Fill, .BackColor = Color.White, .Margin = New Padding(0, 0, 0, 8)}

        Dim head As New Panel With {.Dock = DockStyle.Top, .Height = 28, .BackColor = Color.FromArgb(251, 244, 243)}
        Dim lbl As New Label With {.Text = "ALERTS", .ForeColor = ClrRed, .Font = New Font("Segoe UI", 8.0F, FontStyle.Bold),
                                   .Location = New Point(10, 7), .AutoSize = True}
        lblAlertCount = New Label With {.Text = "0", .BackColor = ClrRed, .ForeColor = Color.White,
                                        .Font = New Font("Segoe UI", 8.0F, FontStyle.Bold),
                                        .Location = New Point(62, 5), .AutoSize = True, .Padding = New Padding(5, 1, 5, 1)}
        head.Controls.Add(lbl) : head.Controls.Add(lblAlertCount)

        pnlAlertsList = New FlowLayoutPanel With {
            .Dock = DockStyle.Fill, .FlowDirection = FlowDirection.TopDown,
            .WrapContents = False, .AutoScroll = True, .BackColor = Color.White}
        host.Controls.Add(pnlAlertsList)
        host.Controls.Add(head)
        Return Bordered(host)
    End Function

    Private Function BuildKpiRow() As Control
        Dim row As New TableLayoutPanel With {.Dock = DockStyle.Fill, .ColumnCount = 5, .RowCount = 1,
                                              .BackColor = Me.BackColor, .Margin = New Padding(0, 0, 0, 8)}
        For i As Integer = 1 To 5
            row.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20))
        Next
        row.Controls.Add(MakeKpiTile("TOTAL WORKFLOWS", Color.Empty, lblKpiTotal, lblKpiTotalSub, Color.FromArgb(34, 37, 40)), 0, 0)
        row.Controls.Add(MakeKpiTile("SUCCESS", ClrGreen, lblKpiSuccess, lblKpiSuccessSub, ClrGreen), 1, 0)
        row.Controls.Add(MakeKpiTile("FAILURE", ClrRed, lblKpiFailure, lblKpiFailureSub, ClrRed), 2, 0)
        row.Controls.Add(MakeKpiTile("AVG DURATION", ClrAmber, lblKpiAvg, lblKpiAvgSub, ClrAmber), 3, 0)
        row.Controls.Add(MakeKpiTile("IN PROGRESS", Color.Empty, lblKpiRunning, lblKpiRunningSub, Color.FromArgb(34, 37, 40)), 4, 0)
        Return row
    End Function

    Private Function MakeKpiTile(ByVal caption As String, ByVal accent As Color,
                                 ByRef lblValue As Label, ByRef lblSub As Label,
                                 ByVal valueColor As Color) As Control
        Dim tile As New Panel With {.Dock = DockStyle.Fill, .BackColor = Color.White, .Margin = New Padding(0, 0, 8, 0)}
        If accent <> Color.Empty Then
            Dim strip As New Panel With {.Dock = DockStyle.Top, .Height = 3, .BackColor = accent}
            tile.Controls.Add(strip)
        End If
        Dim cap As New Label With {.Text = caption, .ForeColor = ClrTextMuted,
                                   .Font = New Font("Segoe UI", 7.5F, FontStyle.Bold),
                                   .Location = New Point(12, 9), .AutoSize = True}
        lblValue = New Label With {.Text = "—", .ForeColor = valueColor,
                                   .Font = New Font("Segoe UI", 20.0F, FontStyle.Bold),
                                   .Location = New Point(10, 24), .AutoSize = True}
        lblSub = New Label With {.Text = "", .ForeColor = Color.FromArgb(138, 146, 155),
                                 .Font = New Font("Segoe UI", 7.5F),
                                 .Location = New Point(12, 66), .AutoSize = True}
        tile.Controls.Add(cap) : tile.Controls.Add(lblValue) : tile.Controls.Add(lblSub)
        Return Bordered(tile)
    End Function

    Private Function BuildTopCharts() As Control
        Dim row As New TableLayoutPanel With {.Dock = DockStyle.Fill, .ColumnCount = 2, .RowCount = 1,
                                              .BackColor = Me.BackColor, .Margin = New Padding(0, 0, 0, 8)}
        row.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50))
        row.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50))

        chartFunnel = MakeChart("WORKFLOW FUNNEL — workflows reaching each step (click a bar for details)")
        chartSteps = MakeChart("AVG DURATION PER STEP (s) — click a bar for details")
        AddHandler chartFunnel.MouseClick, Sub(snd As Object, ev As MouseEventArgs) OnChartClick(chartFunnel, ev)
        AddHandler chartSteps.MouseClick, Sub(snd As Object, ev As MouseEventArgs) OnChartClick(chartSteps, ev)
        AddHandler chartFunnel.MouseMove, Sub(snd As Object, ev As MouseEventArgs) OnChartHover(chartFunnel, ev)
        AddHandler chartSteps.MouseMove, Sub(snd As Object, ev As MouseEventArgs) OnChartHover(chartSteps, ev)
        Dim left As Control = Bordered(WrapChart(chartFunnel))
        left.Margin = New Padding(0, 0, 8, 0)
        row.Controls.Add(left, 0, 0)
        row.Controls.Add(Bordered(WrapChart(chartSteps)), 1, 0)
        Return row
    End Function

    Private Function BuildTrendChart() As Control
        chartTrend = MakeChart("THROUGHPUT — workflows per minute (green = completed, red = failed)")
        Dim c As Control = Bordered(WrapChart(chartTrend))
        c.Margin = New Padding(0, 0, 0, 8)
        Return c
    End Function

    Private Function BuildGrids() As Control
        Dim split As New SplitContainer With {
            .Dock = DockStyle.Fill, .Orientation = Orientation.Horizontal,
            .SplitterWidth = 8, .BackColor = Me.BackColor}

        ' ---- live grid ----
        dgvLive = MakeGrid()
        dgvLive.Columns.Add("SubmissionId", "SUBMISSION ID") : dgvLive.Columns(0).FillWeight = 180
        dgvLive.Columns.Add("CaseId", "CASE") : dgvLive.Columns(1).FillWeight = 50
        dgvLive.Columns.Add("CurrentStep", "CURRENT STEP") : dgvLive.Columns(2).FillWeight = 130
        dgvLive.Columns.Add("Status", "STATUS") : dgvLive.Columns(3).FillWeight = 90
        dgvLive.Columns.Add("Result", "RESULT") : dgvLive.Columns(4).FillWeight = 110
        dgvLive.Columns.Add("Worker", "WORKER") : dgvLive.Columns(5).FillWeight = 70
        dgvLive.Columns.Add("Started", "STARTED") : dgvLive.Columns(6).FillWeight = 110
        dgvLive.Columns.Add("Ended", "ENDED") : dgvLive.Columns(7).FillWeight = 110
        dgvLive.Columns.Add("Dur", "DUR (s)") : dgvLive.Columns(8).FillWeight = 60
        ' Worksheet id renders as a clickable button; click opens the worksheet popup
        Dim colWs As New DataGridViewButtonColumn With {
            .Name = "Worksheet", .HeaderText = "WORKSHEET ID", .FillWeight = 100,
            .FlatStyle = FlatStyle.Flat, .UseColumnTextForButtonValue = False}
        colWs.DefaultCellStyle.BackColor = Color.White
        colWs.DefaultCellStyle.Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)
        dgvLive.Columns.Add(colWs)
        AddHandler dgvLive.SelectionChanged, AddressOf OnLiveSelectionChanged
        AddHandler dgvLive.CellContentClick, AddressOf OnLiveCellContentClick

        Dim liveHost As New Panel With {.Dock = DockStyle.Fill, .BackColor = Color.White}
        liveHost.Controls.Add(dgvLive)
        liveHost.Controls.Add(BuildLiveFilterBar())
        lblLiveTitle = MakePanelHeader("LIVE WORKFLOWS — latest state per submission (click a row to drill down)")
        liveHost.Controls.Add(lblLiveTitle)
        split.Panel1.Controls.Add(Bordered(liveHost))

        ' ---- drill-down grid ----
        dgvDetail = MakeGrid()
        dgvDetail.Columns.Add("Step", "STEP") : dgvDetail.Columns(0).FillWeight = 140
        dgvDetail.Columns.Add("Status", "STATUS") : dgvDetail.Columns(1).FillWeight = 80
        dgvDetail.Columns.Add("Result", "RESULT") : dgvDetail.Columns(2).FillWeight = 110
        dgvDetail.Columns.Add("Dur", "DUR (s)") : dgvDetail.Columns(3).FillWeight = 60
        dgvDetail.Columns.Add("Start", "START") : dgvDetail.Columns(4).FillWeight = 120
        dgvDetail.Columns.Add("End", "END") : dgvDetail.Columns(5).FillWeight = 120
        dgvDetail.Columns.Add("Details", "DETAILS") : dgvDetail.Columns(6).FillWeight = 280
        AddHandler dgvDetail.CellClick, AddressOf OnDetailCellClick

        Dim detHost As New Panel With {.Dock = DockStyle.Fill, .BackColor = Color.White}
        Dim detHead As New Panel With {.Dock = DockStyle.Top, .Height = 26, .BackColor = ClrGridHead}
        lblDetailTitle = MakePanelHeader("WORKFLOW DETAIL — select a workflow above")
        lblDetailTitle.Dock = DockStyle.Fill
        Dim btnExportDetail As New Button With {.Text = "Export", .Dock = DockStyle.Right, .Width = 76,
            .FlatStyle = FlatStyle.Flat, .ForeColor = Color.FromArgb(47, 92, 143), .BackColor = ClrGridHead}
        btnExportDetail.FlatAppearance.BorderColor = Color.FromArgb(169, 192, 216)
        AddHandler btnExportDetail.Click, Sub() ExportDetailGrid()
        detHead.Controls.Add(lblDetailTitle)
        detHead.Controls.Add(btnExportDetail)
        detHost.Controls.Add(dgvDetail)
        detHost.Controls.Add(detHead)
        split.Panel2.Controls.Add(Bordered(detHost))

        Return split
    End Function

    ''' <summary>Autocomplete filter bar for the live grid (submission id + record case id).</summary>
    Private Function BuildLiveFilterBar() As Control
        Dim bar As New FlowLayoutPanel With {
            .Dock = DockStyle.Top, .Height = 32, .BackColor = ClrGridHead,
            .Padding = New Padding(6, 3, 6, 3), .WrapContents = False}

        bar.Controls.Add(MakeFilterLabel("Submission ID"))
        txtSubFilter = New TextBox With {.Width = 230,
            .AutoCompleteMode = AutoCompleteMode.SuggestAppend,
            .AutoCompleteSource = AutoCompleteSource.CustomSource}
        AddHandler txtSubFilter.TextChanged, AddressOf OnLiveFilterChanged
        bar.Controls.Add(txtSubFilter)

        bar.Controls.Add(MakeFilterLabel("Record case ID"))
        txtCaseFilter = New TextBox With {.Width = 90,
            .AutoCompleteMode = AutoCompleteMode.SuggestAppend,
            .AutoCompleteSource = AutoCompleteSource.CustomSource}
        AddHandler txtCaseFilter.TextChanged, AddressOf OnLiveFilterChanged
        bar.Controls.Add(txtCaseFilter)

        Dim btnClear As New Button With {.Text = "Clear", .Width = 62, .Height = 24,
            .FlatStyle = FlatStyle.Flat, .ForeColor = ClrRed, .Margin = New Padding(10, 2, 4, 2)}
        btnClear.FlatAppearance.BorderColor = Color.FromArgb(228, 183, 180)
        AddHandler btnClear.Click, Sub()
                                       txtSubFilter.Clear()
                                       txtCaseFilter.Clear()
                                   End Sub
        bar.Controls.Add(btnClear)

        Dim btnExportLive As New Button With {.Text = "Export", .Width = 70, .Height = 24,
            .FlatStyle = FlatStyle.Flat, .ForeColor = Color.FromArgb(47, 92, 143), .Margin = New Padding(10, 2, 4, 2)}
        btnExportLive.FlatAppearance.BorderColor = Color.FromArgb(169, 192, 216)
        AddHandler btnExportLive.Click, Sub() ExportLiveGrid()
        bar.Controls.Add(btnExportLive)
        Return bar
    End Function

    Private Sub OnLiveFilterChanged(ByVal sender As Object, ByVal e As EventArgs)
        If mMetrics IsNot Nothing Then BindLiveGrid()
    End Sub

    ''' <summary>Snapshots matching the two live-grid filter boxes (contains, case-insensitive).</summary>
    Private Function FilteredSnapshots() As List(Of WorkflowSnapshot)
        Dim subF As String = txtSubFilter.Text.Trim()
        Dim caseF As String = txtCaseFilter.Text.Trim()
        Return mMetrics.Snapshots.Where(Function(s) _
            (subF.Length = 0 OrElse s.SubmissionId.IndexOf(subF, StringComparison.OrdinalIgnoreCase) >= 0) AndAlso
            (caseF.Length = 0 OrElse s.RecordCaseId.IndexOf(caseF, StringComparison.OrdinalIgnoreCase) >= 0)).ToList()
    End Function

    ''' <summary>Feed the autocomplete boxes with the distinct ids of the current result set.</summary>
    Private Sub UpdateFilterAutoComplete()
        Dim subSrc As New AutoCompleteStringCollection()
        subSrc.AddRange(mMetrics.Snapshots.Select(Function(s) s.SubmissionId).Distinct().ToArray())
        txtSubFilter.AutoCompleteCustomSource = subSrc
        Dim caseSrc As New AutoCompleteStringCollection()
        caseSrc.AddRange(mMetrics.Snapshots.Select(Function(s) s.RecordCaseId).Distinct().ToArray())
        txtCaseFilter.AutoCompleteCustomSource = caseSrc
    End Sub

    ' ---------------- helpers ----------------
    Private Function MakeFilterLabel(ByVal text As String) As Label
        Return New Label With {.Text = text, .AutoSize = True, .ForeColor = ClrTextMuted, .Margin = New Padding(10, 8, 4, 2)}
    End Function

    Private Function Bordered(ByVal inner As Control) As Control
        Dim wrap As New Panel With {.Dock = If(TypeOf inner.Parent Is Control, DockStyle.Fill, DockStyle.Fill),
                                    .Padding = New Padding(1), .BackColor = ClrPanelBorder, .Margin = inner.Margin}
        inner.Margin = New Padding(0)
        inner.Dock = DockStyle.Fill
        wrap.Controls.Add(inner)
        Return wrap
    End Function

    Private Function MakePanelHeader(ByVal text As String) As Label
        Return New Label With {.Text = text, .Dock = DockStyle.Top, .Height = 26,
                               .Font = New Font("Segoe UI", 8.0F, FontStyle.Bold),
                               .ForeColor = Color.FromArgb(55, 65, 75), .BackColor = ClrGridHead,
                               .TextAlign = ContentAlignment.MiddleLeft, .Padding = New Padding(10, 0, 0, 0)}
    End Function

    Private Function WrapChart(ByVal ch As Chart) As Control
        Dim host As New Panel With {.Dock = DockStyle.Fill, .BackColor = Color.White}
        ch.Dock = DockStyle.Fill
        host.Controls.Add(ch)
        host.Controls.Add(MakePanelHeader(ch.Tag.ToString()))
        Return host
    End Function

    Private Function MakeChart(ByVal title As String) As Chart
        Dim ch As New Chart With {.BackColor = Color.White, .Tag = title}
        Dim area As New ChartArea("main")
        area.AxisX.MajorGrid.Enabled = False
        area.AxisY.MajorGrid.LineColor = Color.FromArgb(237, 239, 241)
        area.AxisX.LabelStyle.Font = New Font("Segoe UI", 7.5F)
        area.AxisY.LabelStyle.Font = New Font("Segoe UI", 7.5F)
        area.AxisX.LineColor = ClrPanelBorder
        area.AxisY.LineColor = ClrPanelBorder
        ch.ChartAreas.Add(area)
        Return ch
    End Function

    Private Function MakeGrid() As DataGridView
        Dim g As New DataGridView With {
            .Dock = DockStyle.Fill, .ReadOnly = True, .AllowUserToAddRows = False,
            .AllowUserToDeleteRows = False, .AllowUserToResizeRows = False,
            .RowHeadersVisible = False, .SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            .MultiSelect = False, .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            .BackgroundColor = Color.White, .BorderStyle = BorderStyle.None,
            .CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
            .GridColor = Color.FromArgb(240, 241, 243), .EnableHeadersVisualStyles = False}
        g.ColumnHeadersDefaultCellStyle.BackColor = ClrGridHead
        g.ColumnHeadersDefaultCellStyle.ForeColor = ClrTextMuted
        g.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI", 7.5F, FontStyle.Bold)
        g.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single
        g.ColumnHeadersHeight = 26
        g.DefaultCellStyle.Font = New Font("Segoe UI", 8.5F)
        g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(220, 232, 245)
        g.DefaultCellStyle.SelectionForeColor = Color.FromArgb(34, 37, 40)
        g.RowTemplate.Height = 24
        Return g
    End Function

    ' =================================================================
    '  DATA / REFRESH
    ' =================================================================
    Private Sub OnRangeChanged(ByVal sender As Object, ByVal e As EventArgs)
        ApplyRangePreset()
        If cboRange.SelectedItem.ToString() <> "Custom" Then RefreshData()
    End Sub

    Private Sub ApplyRangePreset()
        Dim nowT As Date = Date.Now
        Select Case cboRange.SelectedItem.ToString()
            Case "Last 15 minutes" : dtpFrom.Value = nowT.AddMinutes(-15) : dtpTo.Value = nowT
            Case "Last 30 minutes" : dtpFrom.Value = nowT.AddMinutes(-30) : dtpTo.Value = nowT
            Case "Last 1 hour" : dtpFrom.Value = nowT.AddHours(-1) : dtpTo.Value = nowT
            Case "Last 4 hours" : dtpFrom.Value = nowT.AddHours(-4) : dtpTo.Value = nowT
            Case "Today" : dtpFrom.Value = nowT.Date : dtpTo.Value = nowT
        End Select
    End Sub

    Public Sub RefreshData()
        Try
            Me.Cursor = Cursors.WaitCursor
            If cboRange.SelectedItem.ToString() <> "Custom" Then ApplyRangePreset()

            Dim worker As String = If(cboWorker.SelectedItem Is Nothing, "", cboWorker.SelectedItem.ToString())
            Dim status As String = If(cboStatus.SelectedItem Is Nothing, "", cboStatus.SelectedItem.ToString())

            mMetrics = mController.GetDashboard(dtpFrom.Value, dtpTo.Value, worker, status)

            BindAlerts()
            BindKpis()
            BindFunnel()
            BindStepDurations()
            BindTrend()
            UpdateFilterAutoComplete()
            BindLiveGrid()
            RefreshWorkerFilter(worker)

            lblLastRefresh.Text = "Last refresh " & Date.Now.ToString("HH:mm:ss")
        Catch ex As Exception
            MessageBox.Show("Dashboard refresh failed: " & ex.Message, "Claim Workflow Monitor",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            Me.Cursor = Cursors.Default
        End Try
    End Sub

    Private Sub RefreshWorkerFilter(ByVal current As String)
        Dim items As New List(Of String) From {"All"}
        items.AddRange(mMetrics.Workers)
        If items.Count <> cboWorker.Items.Count Then
            cboWorker.Items.Clear()
            cboWorker.Items.AddRange(items.ToArray())
            Dim idx As Integer = items.IndexOf(current)
            cboWorker.SelectedIndex = If(idx >= 0, idx, 0)
        End If
    End Sub

    Private Sub BindAlerts()
        pnlAlertsList.SuspendLayout()
        pnlAlertsList.Controls.Clear()
        lblAlertCount.Text = mMetrics.Alerts.Count.ToString()
        lblAlertCount.BackColor = If(mMetrics.Alerts.Any(Function(a) a.Severity = "CRITICAL"), ClrRed,
                                  If(mMetrics.Alerts.Count > 0, ClrAmber, ClrGreen))
        If mMetrics.Alerts.Count = 0 Then
            pnlAlertsList.Controls.Add(New Label With {
                .Text = String.Format("No active alerts — system healthy.   (thresholds: failure > {0:F0}% · slow step ≥ {1:F0} s · long-running > {2:F0} s)",
                                      WorkflowMetricsBO.FAILURE_RATE_PCT_THRESHOLD,
                                      WorkflowMetricsBO.SLOW_STEP_SEC,
                                      WorkflowMetricsBO.LONG_RUNNING_SEC),
                .ForeColor = ClrGreen, .AutoSize = True, .Margin = New Padding(12, 8, 0, 0)})
        End If
        For Each a In mMetrics.Alerts
            Dim clr As Color = If(a.Severity = "CRITICAL", ClrRed, ClrAmber)
            Dim txt As New Label With {.Text = a.Title & "  —  " & a.Detail, .ForeColor = Color.FromArgb(34, 37, 40),
                .Font = New Font("Segoe UI", 8.5F), .Location = New Point(95, 4), .AutoSize = True}
            ' Width must never depend solely on ClientSize at bind time — it can be 0 before first layout,
            ' which made rows invisible. Use content width with a sane minimum.
            Dim row As New Panel With {.Height = 24, .Margin = New Padding(0),
                .Width = Math.Max(txt.PreferredWidth + 110, Math.Max(pnlAlertsList.ClientSize.Width - 25, 600))}
            row.Controls.Add(txt)
            row.Controls.Add(New Label With {.Text = a.Severity, .ForeColor = clr,
                .Font = New Font("Segoe UI", 7.5F, FontStyle.Bold), .Location = New Point(12, 5), .Width = 78})
            row.Controls.Add(New Panel With {.BackColor = clr, .Width = 5, .Dock = DockStyle.Left})
            pnlAlertsList.Controls.Add(row)
        Next
        pnlAlertsList.ResumeLayout()
    End Sub

    Private Sub BindKpis()
        lblKpiTotal.Text = mMetrics.TotalWorkflows.ToString()
        lblKpiTotalSub.Text = "in selected range"
        lblKpiSuccess.Text = mMetrics.SuccessPct.ToString("F1") & "%"
        lblKpiSuccessSub.Text = String.Format("{0} of {1} completed", mMetrics.SuccessCount, mMetrics.TotalWorkflows)
        lblKpiFailure.Text = mMetrics.FailurePct.ToString("F1") & "%"
        lblKpiFailureSub.Text = String.Format("{0} failed · threshold {1:F0}%", mMetrics.FailureCount, WorkflowMetricsBO.FAILURE_RATE_PCT_THRESHOLD)
        lblKpiAvg.Text = mMetrics.AvgDurationSec.ToString("F0") & " s"
        lblKpiAvgSub.Text = String.Format("completed workflows · P95 {0:F0} s", mMetrics.P95DurationSec)
        lblKpiRunning.Text = mMetrics.InProgressCount.ToString()
        lblKpiRunningSub.Text = If(mMetrics.InProgressCount > 0,
                                   String.Format("oldest running {0:F0} s", mMetrics.OldestRunningSec), "none running")
    End Sub

    Private Sub BindFunnel()
        chartFunnel.Series.Clear()
        Dim s As New Series("funnel") With {.ChartType = SeriesChartType.Bar, .Color = ClrBar, .IsValueShownAsLabel = True}
        s.Font = New Font("Segoe UI", 7.5F)
        ' Bar chart draws the first point at the bottom -> add in reverse for top-down reading
        For i As Integer = mMetrics.Funnel.Count - 1 To 0 Step -1
            Dim f = mMetrics.Funnel(i)
            Dim idx As Integer = s.Points.AddXY(f.StepName, f.Count)
            s.Points(idx).Label = String.Format("{0} ({1:F0}%)", f.Count, f.Pct)
            s.Points(idx).ToolTip = String.Format("{0}: {1} of {2} workflows ({3:F0}%) — click for details",
                                                  f.StepName, f.Count, mMetrics.TotalWorkflows, f.Pct)
        Next
        chartFunnel.Series.Add(s)
    End Sub

    Private Sub BindStepDurations()
        chartSteps.Series.Clear()
        Dim s As New Series("steps") With {.ChartType = SeriesChartType.Bar, .IsValueShownAsLabel = True}
        s.Font = New Font("Segoe UI", 7.5F)
        For i As Integer = mMetrics.StepDurations.Count - 1 To 0 Step -1
            Dim sd = mMetrics.StepDurations(i)
            Dim idx As Integer = s.Points.AddXY(sd.StepName, Math.Round(sd.AvgSec, 1))
            s.Points(idx).Color = If(sd.IsBottleneck, ClrRed,
                                  If(sd.AvgSec >= WorkflowMetricsBO.SLOW_STEP_SEC, ClrBarSlow, ClrBar))
            s.Points(idx).ToolTip = String.Format("{0}: avg {1:F1} s · max {2:F1} s · {3} executions — click for details",
                                                  sd.StepName, sd.AvgSec, sd.MaxSec, sd.SampleCount)
        Next
        chartSteps.Series.Add(s)
    End Sub

    Private Sub BindTrend()
        chartTrend.Series.Clear()
        Dim ok As New Series("Completed") With {.ChartType = SeriesChartType.Line, .Color = ClrGreen, .BorderWidth = 2, .XValueType = ChartValueType.DateTime}
        Dim ko As New Series("Failed") With {.ChartType = SeriesChartType.Line, .Color = ClrRed, .BorderWidth = 2, .XValueType = ChartValueType.DateTime}
        ' Sync the X axis with the selected range: pin min/max to From/To
        ' and choose a label format that fits the span (minutes vs days).
        Dim span As TimeSpan = dtpTo.Value - dtpFrom.Value
        Dim tipFmt As String = If(span.TotalDays > 1, "MM/dd HH:mm", "HH:mm")
        For Each tp In mMetrics.Trend
            Dim iOk As Integer = ok.Points.AddXY(tp.BucketStart, tp.Completed)
            ok.Points(iOk).ToolTip = tp.BucketStart.ToString(tipFmt) & " — " & tp.Completed & " completed"
            Dim iKo As Integer = ko.Points.AddXY(tp.BucketStart, tp.Failed)
            ko.Points(iKo).ToolTip = tp.BucketStart.ToString(tipFmt) & " — " & tp.Failed & " failed"
        Next
        Dim ax As Axis = chartTrend.ChartAreas(0).AxisX
        ax.Minimum = dtpFrom.Value.ToOADate()
        ax.Maximum = dtpTo.Value.ToOADate()
        ax.IntervalAutoMode = IntervalAutoMode.VariableCount
        If span.TotalDays > 3 Then
            ax.LabelStyle.Format = "MM/dd"
        ElseIf span.TotalHours > 12 Then
            ax.LabelStyle.Format = "MM/dd HH:mm"
        Else
            ax.LabelStyle.Format = "HH:mm"
        End If
        chartTrend.Series.Add(ok)
        chartTrend.Series.Add(ko)
    End Sub

    Private Sub BindLiveGrid()
        Dim snaps As List(Of WorkflowSnapshot) = FilteredSnapshots()
        lblLiveTitle.Text = String.Format("LIVE WORKFLOWS — {0} workflow(s) (click a row to drill down · click a worksheet id to open it)", snaps.Count)
        dgvLive.SuspendLayout()
        dgvLive.Rows.Clear()
        For Each s In snaps
            Dim endedTxt As String = If(s.EndTs > Date.MinValue, s.EndTs.ToString("MM/dd HH:mm:ss"), "—")
            Dim idx As Integer = dgvLive.Rows.Add(
                s.SubmissionId, s.RecordCaseId, s.CurrentStep, s.Status,
                If(String.IsNullOrEmpty(s.ResultCode), "—", s.ResultCode), s.WorkerId,
                s.StartTs.ToString("MM/dd HH:mm:ss"), endedTxt,
                s.DurationSec.ToString("F0"),
                If(String.IsNullOrEmpty(s.WorksheetId), "—", s.WorksheetId))
            Dim row As DataGridViewRow = dgvLive.Rows(idx)
            row.Tag = s
            If Not String.IsNullOrEmpty(s.WorksheetId) Then
                row.Cells(9).Style.Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)
                row.Cells(9).Style.ForeColor = Color.FromArgb(47, 92, 143)
            End If
            Select Case s.Status
                Case "FAILED"
                    row.DefaultCellStyle.BackColor = ClrRedRow
                    row.Cells(3).Style.ForeColor = ClrRed
                    row.Cells(3).Style.Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)
                Case "RUNNING"
                    row.DefaultCellStyle.BackColor = ClrAmberRow
                    row.Cells(3).Style.ForeColor = ClrAmber
                    row.Cells(3).Style.Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)
                Case Else
                    row.Cells(3).Style.ForeColor = ClrGreen
            End Select
        Next
        dgvLive.ResumeLayout()
        If dgvLive.Rows.Count > 0 Then
            dgvLive.Rows(0).Selected = True
        Else
            dgvDetail.Rows.Clear()
            lblDetailTitle.Text = "WORKFLOW DETAIL — no workflows match"
        End If
    End Sub

    ' =================================================================
    '  WORKSHEET POPUP — click the WORKSHEET ID button in the live grid
    ' =================================================================
    Private Sub OnLiveCellContentClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs)
        If e.RowIndex < 0 OrElse dgvLive.Columns(e.ColumnIndex).Name <> "Worksheet" Then Return
        Dim snap As WorkflowSnapshot = TryCast(dgvLive.Rows(e.RowIndex).Tag, WorkflowSnapshot)
        If snap Is Nothing OrElse String.IsNullOrEmpty(snap.WorksheetId) Then Return
        ShowWorksheetPopup(snap)
    End Sub

    ''' <summary>Small modal that receives the worksheet id and shows it with its workflow context.</summary>
    Private Sub ShowWorksheetPopup(ByVal snap As WorkflowSnapshot)
        Dim dlg As New Form With {
            .Text = "Worksheet", .ClientSize = New Size(400, 226),
            .FormBorderStyle = FormBorderStyle.FixedDialog,
            .StartPosition = FormStartPosition.CenterParent, .Font = Me.Font,
            .MinimizeBox = False, .MaximizeBox = False, .ShowIcon = False, .BackColor = Color.White}

        dlg.Controls.Add(New Label With {.Text = "WORKSHEET ID", .ForeColor = ClrTextMuted,
            .Font = New Font("Segoe UI", 7.5F, FontStyle.Bold), .Location = New Point(20, 16), .AutoSize = True})
        dlg.Controls.Add(New Label With {.Text = snap.WorksheetId, .ForeColor = Color.FromArgb(47, 92, 143),
            .Font = New Font("Segoe UI", 22.0F, FontStyle.Bold), .Location = New Point(18, 32), .AutoSize = True})

        dlg.Controls.Add(New Panel With {.BackColor = ClrPanelBorder, .Location = New Point(20, 104), .Size = New Size(360, 1)})
        dlg.Controls.Add(New Label With {.Text = "Submission ID", .ForeColor = ClrTextMuted, .Location = New Point(20, 116), .AutoSize = True})
        dlg.Controls.Add(New Label With {.Text = snap.SubmissionId, .Font = New Font("Segoe UI", 9.0F, FontStyle.Bold),
            .Location = New Point(130, 116), .Size = New Size(250, 30)})
        dlg.Controls.Add(New Label With {.Text = "Record case ID", .ForeColor = ClrTextMuted, .Location = New Point(20, 146), .AutoSize = True})
        dlg.Controls.Add(New Label With {.Text = snap.RecordCaseId, .Font = New Font("Segoe UI", 9.0F, FontStyle.Bold),
            .Location = New Point(130, 146), .AutoSize = True})

        Dim btnCopy As New Button With {.Text = "Copy ID", .Width = 84, .Height = 26,
            .FlatStyle = FlatStyle.Flat, .Location = New Point(204, 184)}
        AddHandler btnCopy.Click, Sub() Clipboard.SetText(snap.WorksheetId)
        Dim btnClose As New Button With {.Text = "Close", .Width = 84, .Height = 26,
            .FlatStyle = FlatStyle.Flat, .BackColor = Color.FromArgb(47, 92, 143), .ForeColor = Color.White,
            .Location = New Point(296, 184)}
        btnClose.FlatAppearance.BorderSize = 0
        AddHandler btnClose.Click, Sub() dlg.Close()
        dlg.Controls.Add(btnCopy) : dlg.Controls.Add(btnClose)
        dlg.CancelButton = btnClose
        dlg.ShowDialog(Me)
    End Sub

    ' =================================================================
    '  CHART INTERACTIVITY — hover cursor + click-through to step detail
    ' =================================================================
    Private Sub OnChartHover(ByVal ch As Chart, ByVal e As MouseEventArgs)
        Dim hit As HitTestResult = ch.HitTest(e.X, e.Y)
        ch.Cursor = If(hit.ChartElementType = ChartElementType.DataPoint, Cursors.Hand, Cursors.Default)
    End Sub

    Private Sub OnChartClick(ByVal ch As Chart, ByVal e As MouseEventArgs)
        Dim hit As HitTestResult = ch.HitTest(e.X, e.Y)
        If hit.ChartElementType = ChartElementType.DataPoint AndAlso hit.PointIndex >= 0 Then
            Dim stepName As String = hit.Series.Points(hit.PointIndex).AxisLabel
            If Not String.IsNullOrEmpty(stepName) Then ShowStepDetail(stepName)
        End If
    End Sub

    ''' <summary>Modal dialog listing every execution of one step across the current snapshots.</summary>
    Private Sub ShowStepDetail(ByVal stepName As String)
        If mMetrics Is Nothing Then Return

        Dim g As DataGridView = MakeGrid()
        g.Columns.Add("Submission", "SUBMISSION ID") : g.Columns(0).FillWeight = 170
        g.Columns.Add("Status", "STATUS") : g.Columns(1).FillWeight = 80
        g.Columns.Add("Result", "RESULT") : g.Columns(2).FillWeight = 110
        g.Columns.Add("Dur", "DUR (s)") : g.Columns(3).FillWeight = 60
        g.Columns.Add("Start", "START") : g.Columns(4).FillWeight = 110
        g.Columns.Add("Ws", "CREATED WS ID") : g.Columns(5).FillWeight = 95
        g.Columns.Add("Details", "DETAILS") : g.Columns(6).FillWeight = 280

        Dim durs As New List(Of Double)
        For Each snap In mMetrics.Snapshots
            For Each st In snap.Steps.Where(Function(x) String.Equals(x.STEPNAME, stepName, StringComparison.OrdinalIgnoreCase))
                Dim durTxt As String = "—"
                If st.ENDTS > Date.MinValue AndAlso st.STARTTS > Date.MinValue Then
                    Dim d As Double = (st.ENDTS - st.STARTTS).TotalSeconds
                    durs.Add(d) : durTxt = d.ToString("F1")
                End If
                Dim details As String = If(String.IsNullOrEmpty(st.ERRORMESSAGE), st.RESULTDETAILS, st.ERRORMESSAGE)
                Dim wsTxt As String = If(String.IsNullOrEmpty(st.CREATEDWORKSHEETID) OrElse st.CREATEDWORKSHEETID = "0", "—", st.CREATEDWORKSHEETID)
                Dim idx As Integer = g.Rows.Add(snap.SubmissionId, st.STATUS,
                    If(String.IsNullOrEmpty(st.RESULTCODE), "—", st.RESULTCODE),
                    durTxt, st.STARTTS.ToString("MM/dd HH:mm:ss"), wsTxt, If(details, ""))
                Dim row As DataGridViewRow = g.Rows(idx)
                If wsTxt <> "—" Then
                    row.Cells(5).Style.Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)
                    row.Cells(5).Style.ForeColor = ClrGreen
                End If
                Select Case st.STATUS.ToUpperInvariant()
                    Case "FAILED"
                        row.DefaultCellStyle.BackColor = ClrRedRow : row.Cells(1).Style.ForeColor = ClrRed
                    Case "STARTED"
                        row.DefaultCellStyle.BackColor = ClrAmberRow : row.Cells(1).Style.ForeColor = ClrAmber
                    Case Else
                        row.Cells(1).Style.ForeColor = ClrGreen
                End Select
            Next
        Next

        Dim summary As String = String.Format("STEP DETAIL — {0}   ({1} executions", stepName, g.Rows.Count)
        If durs.Count > 0 Then
            summary &= String.Format(" · avg {0:F1} s · max {1:F1} s", durs.Average(), durs.Max())
        End If
        summary &= ")"

        Dim dlg As New Form With {
            .Text = "Step detail — " & stepName, .Size = New Size(1040, 420),
            .StartPosition = FormStartPosition.CenterParent, .Font = Me.Font,
            .MinimizeBox = False, .ShowIcon = False, .BackColor = Color.White}
        dlg.Controls.Add(g)
        dlg.Controls.Add(MakePanelHeader(summary))
        dlg.ShowDialog(Me)
    End Sub

    ' =================================================================
    '  STEP DETAILS POPUP — click a row in the workflow detail grid
    ' =================================================================
    Private Sub OnDetailCellClick(ByVal sender As Object, ByVal e As DataGridViewCellEventArgs)
        If e.RowIndex < 0 Then Return
        Dim row As DataGridViewRow = dgvDetail.Rows(e.RowIndex)
        Dim stepName As String = Convert.ToString(row.Cells(0).Value)
        Dim status As String = Convert.ToString(row.Cells(1).Value)
        Dim meta As String = String.Format("{0} · {1} → {2}",
            Convert.ToString(row.Cells(3).Value) & " s", Convert.ToString(row.Cells(4).Value), Convert.ToString(row.Cells(5).Value))
        Dim details As String = Convert.ToString(row.Cells(6).Value)
        If String.IsNullOrWhiteSpace(details) OrElse details = "—" Then details = "No details recorded for this step."

        Dim dlg As New Form With {
            .Text = "Step details — " & stepName, .ClientSize = New Size(520, 300),
            .FormBorderStyle = FormBorderStyle.FixedDialog,
            .StartPosition = FormStartPosition.CenterParent, .Font = Me.Font,
            .MinimizeBox = False, .MaximizeBox = False, .ShowIcon = False, .BackColor = Color.White}

        Dim clr As Color = If(status = "FAILED", ClrRed, If(status = "STARTED" OrElse status = "RUNNING", ClrAmber, ClrGreen))
        Dim bg As Color = If(status = "FAILED", ClrRedBg, If(status = "STARTED" OrElse status = "RUNNING", ClrAmberBg, ClrGreenBg))
        dlg.Controls.Add(New Label With {.Text = status, .ForeColor = clr, .BackColor = bg,
            .Font = New Font("Segoe UI", 7.5F, FontStyle.Bold), .Location = New Point(20, 14),
            .AutoSize = True, .Padding = New Padding(6, 2, 6, 2)})
        dlg.Controls.Add(New Label With {.Text = meta, .ForeColor = ClrTextMuted,
            .Location = New Point(110, 17), .AutoSize = True})
        dlg.Controls.Add(New Label With {.Text = "DETAILS", .ForeColor = ClrTextMuted,
            .Font = New Font("Segoe UI", 7.5F, FontStyle.Bold), .Location = New Point(20, 44), .AutoSize = True})

        Dim txt As New TextBox With {
            .Multiline = True, .ReadOnly = True, .ScrollBars = ScrollBars.Vertical,
            .Text = details, .BackColor = Color.FromArgb(249, 250, 251), .BorderStyle = BorderStyle.FixedSingle,
            .Location = New Point(20, 62), .Size = New Size(480, 186)}
        dlg.Controls.Add(txt)

        Dim btnClose As New Button With {.Text = "Close", .Width = 84, .Height = 26,
            .FlatStyle = FlatStyle.Flat, .BackColor = Color.FromArgb(47, 92, 143), .ForeColor = Color.White,
            .Location = New Point(416, 258)}
        btnClose.FlatAppearance.BorderSize = 0
        AddHandler btnClose.Click, Sub() dlg.Close()
        dlg.Controls.Add(btnClose)
        dlg.CancelButton = btnClose
        AddHandler dlg.Shown, Sub()
                                  txt.SelectionStart = 0
                                  txt.SelectionLength = 0
                                  btnClose.Focus()
                              End Sub
        dlg.ShowDialog(Me)
    End Sub

    ' =================================================================
    '  EXPORT TO EXCEL (CSV — opens directly in Excel, no Interop needed)
    ' =================================================================
    Private Sub ExportLiveGrid()
        If mMetrics Is Nothing Then Return
        Dim snaps As List(Of WorkflowSnapshot) = FilteredSnapshots()
        If snaps.Count = 0 Then
            MessageBox.Show("No rows to export.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        Dim headers As String() = {"SUBMISSION_ID", "RECORD_CASE_ID", "CURRENT_STEP", "STATUS",
                                   "RESULT_CODE", "WORKER_ID", "STARTED", "ENDED", "DURATION_SEC", "WORKSHEET_ID"}
        Dim rows As New List(Of String())
        For Each s In snaps
            rows.Add(New String() {
                s.SubmissionId, s.RecordCaseId, s.CurrentStep, s.Status, s.ResultCode, s.WorkerId,
                s.StartTs.ToString("MM/dd/yyyy HH:mm:ss"),
                If(s.EndTs > Date.MinValue, s.EndTs.ToString("MM/dd/yyyy HH:mm:ss"), ""),
                s.DurationSec.ToString("F1"), s.WorksheetId})
        Next
        SaveCsv("live_workflows_" & Date.Now.ToString("yyyyMMdd_HHmmss"), headers, rows)
    End Sub

    Private Sub ExportDetailGrid()
        If mCurrentSnap Is Nothing Then
            MessageBox.Show("Select a workflow in the live grid first.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If
        ' EDI_TRANS_IDS / INFORCEALPHA_IDS are exported but stay hidden in the grid.
        ' Adjust the two property names below if they differ on your ClaimWorkflowHistory entity.
        Dim headers As String() = {"SUBMISSION_ID", "RECORD_CASE_ID", "STEP", "STATUS", "RESULT_CODE",
                                   "DURATION_SEC", "START", "END", "DETAILS", "EDI_TRANS_IDS", "INFORCEALPHA_IDS"}
        Dim rows As New List(Of String())
        For Each st In mCurrentSnap.Steps
            Dim durTxt As String = ""
            Dim endTxt As String = ""
            If st.ENDTS > Date.MinValue Then
                durTxt = (st.ENDTS - st.STARTTS).TotalSeconds.ToString("F1")
                endTxt = st.ENDTS.ToString("MM/dd/yyyy HH:mm:ss.fff")
            End If
            Dim details As String = If(String.IsNullOrEmpty(st.ERRORMESSAGE), st.RESULTDETAILS, st.ERRORMESSAGE)
            rows.Add(New String() {
                mCurrentSnap.SubmissionId, mCurrentSnap.RecordCaseId, st.STEPNAME, st.STATUS,
                st.RESULTCODE, durTxt, st.STARTTS.ToString("MM/dd/yyyy HH:mm:ss.fff"), endTxt,
                If(details, ""), If(st.EDITRANSIDS, ""), If(st.INFORCEALPHAIDS, "")})
        Next
        SaveCsv("workflow_detail_" & SafeFileName(mCurrentSnap.SubmissionId), headers, rows)
    End Sub

    Private Sub SaveCsv(ByVal suggestedName As String, ByVal headers As String(), ByVal rows As List(Of String()))
        Using dlg As New SaveFileDialog With {
            .Filter = "CSV (Excel)|*.csv", .FileName = suggestedName & ".csv",
            .Title = "Export to Excel"}
            If dlg.ShowDialog(Me) <> DialogResult.OK Then Return
            Try
                Dim sb As New System.Text.StringBuilder()
                sb.AppendLine(String.Join(",", headers.Select(AddressOf CsvEscape)))
                For Each r In rows
                    sb.AppendLine(String.Join(",", r.Select(AddressOf CsvEscape)))
                Next
                ' UTF-8 BOM so Excel detects the encoding
                System.IO.File.WriteAllText(dlg.FileName, sb.ToString(), New System.Text.UTF8Encoding(True))
                If MessageBox.Show("Exported " & rows.Count & " row(s)." & vbCrLf & "Open the file now?",
                                   "Export", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = DialogResult.Yes Then
                    Process.Start(dlg.FileName)
                End If
            Catch ex As Exception
                MessageBox.Show("Export failed: " & ex.Message, "Export", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    Private Shared Function CsvEscape(ByVal v As String) As String
        If v Is Nothing Then Return ""
        If v.IndexOfAny(New Char() {","c, """"c, Chr(10), Chr(13)}) >= 0 Then
            Return """" & v.Replace("""", """""") & """"
        End If
        Return v
    End Function

    Private Shared Function SafeFileName(ByVal s As String) As String
        For Each c In System.IO.Path.GetInvalidFileNameChars()
            s = s.Replace(c, "_"c)
        Next
        Return s.Replace(":", "_")
    End Function

    Private Sub OnLiveSelectionChanged(ByVal sender As Object, ByVal e As EventArgs)
        If dgvLive.SelectedRows.Count = 0 Then Return
        Dim snap As WorkflowSnapshot = TryCast(dgvLive.SelectedRows(0).Tag, WorkflowSnapshot)
        If snap Is Nothing Then Return
        mCurrentSnap = snap

        lblDetailTitle.Text = String.Format("WORKFLOW DETAIL — {0}   ({1} steps · {2} · {3:F0} s)",
                                            snap.SubmissionId, snap.Steps.Count, snap.Status, snap.DurationSec)
        dgvDetail.SuspendLayout()
        dgvDetail.Rows.Clear()
        For Each st In snap.Steps
            Dim durTxt As String = "—"
            Dim endTxt As String = "—"
            If st.ENDTS > Date.MinValue Then
                durTxt = (st.ENDTS - st.STARTTS).TotalSeconds.ToString("F1")
                endTxt = st.ENDTS.ToString("HH:mm:ss.fff")
            ElseIf String.Equals(st.STATUS, "STARTED", StringComparison.OrdinalIgnoreCase) Then
                durTxt = (Date.Now - st.STARTTS).TotalSeconds.ToString("F0") & " (running)"
            End If
            Dim details As String = If(String.IsNullOrEmpty(st.ERRORMESSAGE), st.RESULTDETAILS, st.ERRORMESSAGE)
            Dim idx As Integer = dgvDetail.Rows.Add(
                st.STEPNAME, st.STATUS, If(String.IsNullOrEmpty(st.RESULTCODE), "—", st.RESULTCODE),
                durTxt, st.STARTTS.ToString("HH:mm:ss.fff"), endTxt, If(details, ""))
            Dim row As DataGridViewRow = dgvDetail.Rows(idx)
            Select Case st.STATUS
                Case "FAILED"
                    row.DefaultCellStyle.BackColor = ClrRedRow
                    row.Cells(1).Style.ForeColor = ClrRed
                Case "STARTED"
                    row.DefaultCellStyle.BackColor = ClrAmberRow
                    row.Cells(1).Style.ForeColor = ClrAmber
                Case Else
                    row.Cells(1).Style.ForeColor = ClrGreen
            End Select
        Next
        dgvDetail.ResumeLayout()
    End Sub

End Class
