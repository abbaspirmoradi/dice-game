' =====================================================================
'  WorkflowDashboardModels.vb
'  DTOs shared by the dashboard Form / Controller / Business layer.
'  Architecture: Form -> WorkflowDashboardController -> WorkflowMetricsBO -> ClaimWorkflowHistoryDLC
' =====================================================================
Option Explicit On

Imports System.Collections.Generic

''' <summary>Latest state of one workflow (one SUBMISSION_ID), plus its full step history.</summary>
Public Class WorkflowSnapshot
    Public Property SubmissionId As String = ""
    Public Property RecordCaseId As String = ""
    Public Property CurrentStep As String = ""
    ''' <summary>COMPLETED | FAILED | RUNNING</summary>
    Public Property Status As String = ""
    Public Property ResultCode As String = ""
    Public Property WorkerId As String = ""
    Public Property StartTs As Date = Date.MinValue
    ''' <summary>Date.MinValue while still running.</summary>
    Public Property EndTs As Date = Date.MinValue
    Public Property DurationSec As Double
    Public Property WorksheetId As String = ""
    ''' <summary>True when the id came from CREATED_WORKSHEET_ID of a completed CreateWorksheet step.</summary>
    Public Property WorksheetCreated As Boolean
    ''' <summary>What the service found/created: WS_CREATED | WS_FOUND | CLAIM_FOUND | "" (nothing).</summary>
    Public Property RefKind As String = ""
    ''' <summary>The id(s) behind RefKind — several entries when multiple claims/worksheets were found.</summary>
    Public Property RefIds As New List(Of String)
    ''' <summary>Details / error text of the latest step, for the live grid.</summary>
    Public Property LastDetails As String = ""
    Public Property ErrorMessage As String = ""
    Public Property Steps As New List(Of ClaimWorkflowHistory)
End Class

Public Class StepCount
    Public Property StepName As String = ""
    Public Property Count As Integer
    Public Property Pct As Double
End Class

Public Class StepDuration
    Public Property StepName As String = ""
    Public Property AvgSec As Double
    Public Property MaxSec As Double
    Public Property SampleCount As Integer
    Public Property IsBottleneck As Boolean
End Class

Public Class TrendPoint
    Public Property BucketStart As Date
    ''' <summary>Bucket width in minutes (set by the BO; buckets widen on long ranges).</summary>
    Public Property BucketMinutes As Integer = 1
    Public Property Completed As Integer
    Public Property Failed As Integer
End Class

Public Class AlertItem
    ''' <summary>CRITICAL | WARNING</summary>
    Public Property Severity As String = ""
    Public Property Title As String = ""
    Public Property Detail As String = ""
    Public Property RaisedAt As Date = Date.Now
End Class

''' <summary>Everything the dashboard needs for one refresh.</summary>
Public Class DashboardMetrics
    Public Property FromTime As Date
    Public Property ToTime As Date

    ' --- Executive KPIs ---
    Public Property TotalWorkflows As Integer
    Public Property SuccessCount As Integer
    Public Property FailureCount As Integer
    Public Property InProgressCount As Integer
    Public Property SuccessPct As Double
    Public Property FailurePct As Double
    Public Property AvgDurationSec As Double
    Public Property P95DurationSec As Double
    Public Property OldestRunningSec As Double

    Public Property Funnel As New List(Of StepCount)
    Public Property StepDurations As New List(Of StepDuration)
    Public Property Trend As New List(Of TrendPoint)
    Public Property Alerts As New List(Of AlertItem)
    Public Property Snapshots As New List(Of WorkflowSnapshot)
    Public Property Workers As New List(Of String)
End Class
